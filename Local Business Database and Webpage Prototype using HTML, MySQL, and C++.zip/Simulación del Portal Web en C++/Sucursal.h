// Semana 18 Cierre de Etapa de Exploración
// Escenario situacional: Declaración de clase Sucursal
// 25 de octubre del 2022

#ifndef sucursal_h
#define sucursal_h
#include <iostream>
#include <vector>
using namespace std;

class Sucursal{
    public:
        Sucursal();
        Sucursal(int _id, string _telefono, string _calle, int _numDomicilio, int _codigoPostal, string _ciudad);
        int getId();
        string getTelefono();
        string getCalle();
        int getNumDomicilio();
        int getCodigoPostal();
        string getCiudad();
    private:
        int id;
        string telefono;
        string calle;
        int numDomicilio;
        int codigoPostal;
        string ciudad;
};

Sucursal::Sucursal(){
    id = 0;
    telefono = " ";
    calle = " ";
    numDomicilio = 0;
    codigoPostal = 0;
    ciudad = " ";
}
Sucursal::Sucursal(int _id, string _telefono, string _calle, int _numDomicilio, int _codigoPostal, string _ciudad){
    id = _id;
    telefono = _telefono;
    calle = _calle;
    numDomicilio = _numDomicilio;
    codigoPostal = _codigoPostal;
    ciudad = _ciudad;
}
int Sucursal::getId(){
    return id;
}
string Sucursal::getTelefono(){
    return telefono;
}
string Sucursal::getCalle(){
    return calle;
}
int Sucursal::getNumDomicilio(){
    return numDomicilio;
}
int Sucursal::getCodigoPostal(){
    return codigoPostal;
}
string Sucursal::getCiudad(){
    return ciudad;
}

#endif