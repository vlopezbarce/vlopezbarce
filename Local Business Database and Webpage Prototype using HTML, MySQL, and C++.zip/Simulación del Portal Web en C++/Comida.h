// Semana 18 Cierre de Etapa de Exploración
// Escenario situacional: Declaración de clase Comida
// 25 de octubre del 2022

#ifndef comida_h
#define comida_h
#include <iostream>
using namespace std;

class Comida{
    public:
        Comida();
        Comida(int _id, string _nombre, int _precio, string _descripcion);
        int getID();
        string getNombre();
        string getDescripcion();
        int getPrecio();
    private:
        int id;
        string nombre;
        int precio;
        string descripcion;
};

Comida::Comida(){
    id = 0;
    nombre = " ";
    descripcion = " ";
    precio = 0;
}
Comida::Comida(int _id, string _nombre, int _precio, string _descripcion){
    id = _id;
    nombre = _nombre;
    precio = _precio;
    descripcion = _descripcion;
}
int Comida::getID(){
    return id;
}
string Comida::getNombre(){
    return nombre;
}
string Comida::getDescripcion(){
    return descripcion;
}
int Comida::getPrecio(){
    return precio;
}

#endif