// Semana 18 Cierre de Etapa de Exploración
// Escenario situacional: Declaración de clase Restaurante
// 25 de octubre del 2022

#ifndef restaurante_h
#define restaurante_h
#include "Sucursal.h"
#include "Cliente.h"
#include "Comida.h"
#include <iostream>
using namespace std;

class Restaurante{
    public:
        Restaurante();
        Restaurante(int _id, string _nombre, vector<Sucursal> _sucursales, vector<Cliente> _clientes, vector<Comida> _comidas);
        int getID();
        string getNombre();
    private:
        int id;
        string nombre;
        vector<Sucursal> sucursales;
        vector<Cliente> clientes;
        vector<Comida> comidas;
};

Restaurante::Restaurante(){
    id = 0;
    nombre = " ";
}
Restaurante::Restaurante(int _id, string _nombre, vector<Sucursal> _sucursales, vector<Cliente> _clientes, vector<Comida> _comidas){
    id = _id;
    nombre = _nombre;
    sucursales = _sucursales;
    clientes = _clientes;
    comidas = _comidas;
}
int Restaurante::getID(){
    return id;
}
string Restaurante::getNombre(){
    return nombre;
}

#endif