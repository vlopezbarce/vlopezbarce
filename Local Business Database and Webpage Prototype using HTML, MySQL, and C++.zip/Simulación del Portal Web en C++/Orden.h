// Semana 18 Cierre de Etapa de Exploración
// Escenario situacional: Declaración de clase Orden
// 25 de octubre del 2022

#ifndef orden_h
#define orden_h
#include "Comida.h"
#include <iostream>
using namespace std;

class Orden{
    public:
        Orden();
        int getId();
        string getFecha();
        string getHoraPedido();
        string getHoraEntrega();
        int getMontoTotal();
        void setId(int _id);
        void setFecha(string _fecha);
        void setHoraPedido(string _horaPedido);
        void setHoraEntrega(string _horaEntrega);
        void calculaMonto(Comida item);
    private:
        int id;
        string fecha;
        string horaPedido;
        string horaEntrega;
        int montoTotal;
};

Orden::Orden(){
    id = 0;
    fecha = " ";
    horaPedido = " ";
    horaEntrega = " ";
    montoTotal = 0;
}
int Orden::getId(){
    return id;
}
string Orden::getFecha(){
    return fecha;
}
string Orden::getHoraPedido(){
    return horaPedido;
}
string Orden::getHoraEntrega(){
    return horaEntrega;
}
int Orden::getMontoTotal(){
    return montoTotal;
}
void Orden::setId(int _id){
    id = _id;
}
void Orden::setFecha(string _fecha){
    fecha = _fecha;
}
void Orden::setHoraPedido(string _horaPedido){
    horaPedido = _horaPedido;
}
void Orden::setHoraEntrega(string _horaEntrega){
    horaEntrega = _horaEntrega;
}
void Orden::calculaMonto(Comida item){
    montoTotal += item.getPrecio();
}

#endif