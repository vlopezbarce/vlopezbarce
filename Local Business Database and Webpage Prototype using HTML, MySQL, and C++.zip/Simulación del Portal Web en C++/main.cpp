// Semana 18 Cierre de Etapa de Exploración: Escenario situacional
// Valeria López Barcelata A00833578
// 25 de octubre del 2022

#include "Restaurante.h"
#include "Sucursal.h"
#include "Cliente.h"
#include "Orden.h"
#include "Comida.h"
#include <fstream>
#include <sstream>
#include <iostream>
using namespace std;

// Función para que el Cliente acumule puntos después de cada orden
// Complejidad: O(n)
void acumulaPuntos(Orden O, vector<Cliente> clientes, int pos){
    int monto = O.getMontoTotal();
    int puntos = clientes[pos].getPuntos();
    if (monto == 0) return;
    if (puntos != 0){
        cout << "Puntos actuales: " << puntos << endl;
        string opcion;
        cout << "¿Desea utilizar los puntos? (S/N) ";
        cin >> opcion;
        if (opcion == "S"){
            monto -= puntos;
            puntos = (monto > 0) ? 0 : abs(monto);
            monto = (monto > 0) ? monto : 0;
        } else if (opcion == "N"){
            puntos += monto * 0.10;
        } else {
            cout << "Caracter invalido" << endl;
        }
    } else {
        cout << "No cuenta con puntos acumulados" << endl;
        puntos += monto * 0.10;
    }
    cout << "El monto total es: $" << monto << endl;

    clientes[pos].setPuntos(puntos);
    ofstream oclientes;
    oclientes.open("clientes.txt");
    for (int i = 0; i < clientes.size(); i++){
        Cliente C = clientes[i];
        oclientes << C.getID() << " " << C.getNombre() << " " << C.getApellido() << " " << C.getCorreo() << " " << C.getPuntos();
        if (i != clientes.size()-1){
            oclientes << endl;
        }
    }
    oclientes.close();
}

// Función para comprobar si la comida existe en la base de datos
// Complejidad: O(n)
bool confirmaComida(Orden &O, int id, vector<Comida> comidas){
    for (int i = 0; i < comidas.size(); i++){
        if (id == comidas[i].getID()){
            O.calculaMonto(comidas[i]);
            return true;
        }
    }
    return false;
}

// Función para ordenar comida y obtener el monto total de la orden
// Complejidad: O(n)
void ordenaComida(vector<Comida> comidas, vector<Cliente> clientes, int pos){
    Orden O;
    int IDComida;
    string opcion;
    cout << "Ingresa los IDs para agregar a tu orden (Escribe 0 para salir): " << endl;
    cin >> IDComida;
    while (IDComida != 0){
        if (!confirmaComida(O, IDComida, comidas)){
          cout << "Comida no existe en la base de datos" << endl;
        }
        cin >> IDComida;
    }
    acumulaPuntos(O, clientes, pos);
}

// Función para crear la cuenta de un cliente y agregar a la base de datos
// Complejidad: O(1)
void crearCliente(vector<Cliente> &clientes){
    string nombre, apellido, correo;
    cout << "Ingresa tu nombre: ";
    cin >> nombre;
    cout << "Ingresa tu apellido: ";
    cin >> apellido;
    cout << "Ingresa tu correo: ";
    cin >> correo;
    int id = clientes[clientes.size()-1].getID() + 1;
    ofstream oclientes;
    oclientes.open("clientes.txt", ios_base::app);
    oclientes << "\n" << id << " " << nombre << " " << apellido << " " << correo << " 0";
    oclientes.close();
    clientes.push_back(Cliente(id, nombre, apellido, correo, 0));
}

// Función para comprobar si el cliente ya existe en la base de datos
// Complejidad: O(n)
bool confirmaCliente(vector<Cliente> clientes, int &pos){
    string correo;
    cout << "Ingresa tu correo: ";
    cin >> correo;
    for (int i = 0; i < clientes.size(); i++){
        if (correo == clientes[i].getCorreo()){
            pos = i;
            cout << "\nBienvenidx " << clientes[i].getNombre() << endl;
            return true;
        }
    }
    return false;
}

// Función para confirmar la orden del cliente
// Complejidad: O(n)
void confirmaOrden(vector<Cliente> clientes, vector<Comida> comidas){
    string ordenar;
    cout << "\n¿Estas listx para ordenar? (S/N) ";
    cin >> ordenar;
    if (ordenar == "N"){
        cout << "¡Hasta luego!" << endl;
    } else if (ordenar == "S"){
        int pos = -1;
        if (confirmaCliente(clientes, pos)){
            ordenaComida(comidas, clientes, pos);
            cout << "¡Gracias por ordenar!" << endl;
        } else {
            cout << "Correo no registrado" << endl;
            string crear;
            cout << "¿Desea crear una cuenta? (S/N) ";
            cin >> crear;
            if (crear == "N"){
              cout << "¡Hasta luego!" << endl;
            } else {
              crearCliente(clientes);
              confirmaOrden(clientes, comidas);
            }
        }
    } else {
        cout << "Caracter invalido" << endl;
    }
}

int main(){
    ifstream isucursales;
    ifstream iclientes;
    ifstream icomidas;
    vector<Sucursal> sucursales;
    vector<Cliente> clientes;
    vector<Comida> comidas;

    // Leer datos Sucursales del archivo "sucursales.txt"
    isucursales.open("sucursales.txt", ios::in);
    while (!isucursales.eof() && isucursales.is_open()){
        int id, num, cp;
        string tel, calle, ciudad;
        isucursales >> id >> tel >> calle >> num >> cp >> ciudad;
        // Crear objeto Sucursal con sus atributos
        Sucursal S(id, tel, calle, num, cp, ciudad);
        // Agregar al vector de sucursales
        sucursales.push_back(S);
    }
    isucursales.close();

    // Leer datos Clientes del archivo "clientes.txt"
    iclientes.open("clientes.txt", ios::in);
    while (!iclientes.eof() && iclientes.is_open()){
        int id, puntos;
        string nombre, apellido, correo;
        iclientes >> id >> nombre >> apellido >> correo >> puntos;
        // Crear objeto Cliente con sus atributos
        Cliente C(id, nombre, apellido, correo, puntos);
        // Agregar al vector de clientes
        clientes.push_back(C);
    }
    iclientes.close();

    // Leer datos Comidas del archivo "comidas.txt"
    icomidas.open("comidas.txt", ios::in);
    while (!icomidas.eof() && icomidas.is_open()){
        int id, precio;
        string nombre, desc;
        icomidas >> id >> nombre >> precio;
        getline(icomidas, desc);
        // Crear objeto Comida con sus atributos
        Comida C(id, nombre, precio, desc);
        // Agregar al vector de comidas
        comidas.push_back(C);
    }
    icomidas.close();

    // Asignar datos al Restaurante "El Taquito"
    Restaurante R(899, "El Taquito", sucursales, clientes, comidas);

    // Desplegar el menú del restaurante
    cout << "Bienvenidx al restaurante " << R.getNombre() << endl << endl;
    cout << "Presentamos nuestro menú: " << endl;
    for (int i = 0; i < comidas.size(); i++){
        cout << "#" << comidas[i].getID() << " " << comidas[i].getNombre() << " $" << comidas[i].getPrecio() << endl;
        cout << comidas[i].getDescripcion() << endl;
    }

    // Confirmar orden del cliente
    confirmaOrden(clientes, comidas);

    return 0;
}