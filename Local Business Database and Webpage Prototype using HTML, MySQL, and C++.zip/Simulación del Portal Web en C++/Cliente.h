// Semana 18 Cierre de Etapa de Exploración
// Escenario situacional: Declaración de clase Cliente
// 25 de octubre del 2022

#ifndef cliente_h
#define cliente_h
#include <iostream>
#include <vector>
using namespace std;

class Cliente{
    public:
        Cliente();
        Cliente(int _id, string _nombre, string _apellido, string _correo, int _puntos);
        Cliente(int _id, string _nombre, string _apellido, string _correo, string _telefono, string _calle, int _numDomicilio, int _codigoPostal, string _ciudad, int _puntos);
        int getID();
        string getNombre();
        string getApellido();
        string getCorreo();
        string getTelefono();
        string getCalle();
        int getNumDomicilio();
        int getCodigoPostal();
        string getCiudad();
        int getPuntos();
        void setPuntos(int _puntos);
    private:
        int id;
        string nombre;
        string apellido;
        string correo;
        string telefono;
        string calle;
        int numDomicilio;
        int codigoPostal;
        string ciudad;
        int puntos;
};

Cliente::Cliente(){
    id = 0;
    nombre = " ";
    apellido = " ";
    correo = " ";
    telefono = " ";
    calle = " ";
    numDomicilio = 0;
    codigoPostal = 0;
    ciudad = " ";
    puntos = 0;
}
Cliente::Cliente(int _id, string _nombre, string _apellido, string _correo, int _puntos){
    id = _id;
    nombre = _nombre;
    apellido = _apellido;
    correo = _correo;
    puntos = _puntos;
}
Cliente::Cliente(int _id, string _nombre, string _apellido, string _correo, string _telefono, string _calle, int _numDomicilio, int _codigoPostal, string _ciudad, int _puntos){
    id = _id;
    nombre = _nombre;
    apellido = _apellido;
    correo = _correo;
    telefono = _telefono;
    calle = _calle;
    numDomicilio = _numDomicilio;
    codigoPostal = _codigoPostal;
    ciudad = _ciudad;
    puntos = _puntos;
}
int Cliente::getID(){
    return id;
}
string Cliente::getNombre(){
    return nombre;
}
string Cliente::getApellido(){
    return apellido;
}
string Cliente::getCorreo(){
    return correo;
}
string Cliente::getTelefono(){
    return telefono;
}
string Cliente::getCalle(){
    return calle;
}
int Cliente::getNumDomicilio(){
    return numDomicilio;
}
int Cliente::getCodigoPostal(){
    return codigoPostal;
}
string Cliente::getCiudad(){
    return ciudad;
}
int Cliente::getPuntos(){
    return puntos;
}
void Cliente::setPuntos(int _puntos){
    puntos = _puntos;
}
#endif