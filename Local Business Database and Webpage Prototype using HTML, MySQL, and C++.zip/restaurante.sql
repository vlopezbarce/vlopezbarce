-- phpMyAdmin SQL Dump
-- version 5.2.0
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Oct 26, 2022 at 04:31 AM
-- Server version: 10.4.25-MariaDB
-- PHP Version: 8.1.10

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `restaurante`
--

-- --------------------------------------------------------

--
-- Table structure for table `cliente`
--

CREATE TABLE `cliente` (
  `id` int(3) NOT NULL,
  `nombre` varchar(256) DEFAULT NULL,
  `apellido` varchar(256) DEFAULT NULL,
  `correo` varchar(256) DEFAULT NULL,
  `calle` varchar(256) DEFAULT NULL,
  `numero` int(3) DEFAULT NULL,
  `codigo_postal` int(5) DEFAULT NULL,
  `ciudad` varchar(256) DEFAULT NULL,
  `puntos` int(4) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- --------------------------------------------------------

--
-- Table structure for table `cliente_ordena`
--

CREATE TABLE `cliente_ordena` (
  `id_cliente` int(3) NOT NULL,
  `id_orden` int(3) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- --------------------------------------------------------

--
-- Table structure for table `comida`
--

CREATE TABLE `comida` (
  `id` int(3) NOT NULL,
  `nombre` varchar(256) DEFAULT NULL,
  `descripcion` varchar(256) DEFAULT NULL,
  `precio` int(3) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- --------------------------------------------------------

--
-- Table structure for table `orden`
--

CREATE TABLE `orden` (
  `id` int(3) NOT NULL,
  `fecha` date DEFAULT NULL,
  `hora_pedido` int(2) DEFAULT NULL,
  `hora_entrega` int(2) DEFAULT NULL,
  `id_comida` int(3) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- --------------------------------------------------------

--
-- Table structure for table `restaurante`
--

CREATE TABLE `restaurante` (
  `id` int(3) NOT NULL,
  `nombre` varchar(256) DEFAULT NULL,
  `id_sucursal` int(3) NOT NULL,
  `id_cliente` int(3) NOT NULL,
  `id_comida` int(3) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- --------------------------------------------------------

--
-- Table structure for table `sucursal`
--

CREATE TABLE `sucursal` (
  `id` int(3) NOT NULL,
  `calle` varchar(256) DEFAULT NULL,
  `numero` int(3) DEFAULT NULL,
  `codigo_postal` int(5) DEFAULT NULL,
  `ciudad` varchar(256) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- --------------------------------------------------------

--
-- Table structure for table `telefonos_clientes`
--

CREATE TABLE `telefonos_clientes` (
  `id_cliente` int(3) NOT NULL,
  `telefono` varchar(256) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- --------------------------------------------------------

--
-- Table structure for table `telefonos_sucursal`
--

CREATE TABLE `telefonos_sucursal` (
  `id_sucursal` int(3) NOT NULL,
  `telefono` varchar(256) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Indexes for dumped tables
--

--
-- Indexes for table `cliente`
--
ALTER TABLE `cliente`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `cliente_ordena`
--
ALTER TABLE `cliente_ordena`
  ADD PRIMARY KEY (`id_cliente`,`id_orden`),
  ADD KEY `id_orden` (`id_orden`);

--
-- Indexes for table `comida`
--
ALTER TABLE `comida`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `orden`
--
ALTER TABLE `orden`
  ADD PRIMARY KEY (`id`),
  ADD KEY `id_comida` (`id_comida`);

--
-- Indexes for table `restaurante`
--
ALTER TABLE `restaurante`
  ADD PRIMARY KEY (`id`),
  ADD KEY `id_sucursal` (`id_sucursal`),
  ADD KEY `id_cliente` (`id_cliente`),
  ADD KEY `id_comida` (`id_comida`);

--
-- Indexes for table `sucursal`
--
ALTER TABLE `sucursal`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `telefonos_clientes`
--
ALTER TABLE `telefonos_clientes`
  ADD PRIMARY KEY (`id_cliente`,`telefono`);

--
-- Indexes for table `telefonos_sucursal`
--
ALTER TABLE `telefonos_sucursal`
  ADD PRIMARY KEY (`id_sucursal`,`telefono`);

--
-- Constraints for dumped tables
--

--
-- Constraints for table `cliente_ordena`
--
ALTER TABLE `cliente_ordena`
  ADD CONSTRAINT `cliente_ordena_ibfk_1` FOREIGN KEY (`id_cliente`) REFERENCES `cliente` (`id`),
  ADD CONSTRAINT `cliente_ordena_ibfk_2` FOREIGN KEY (`id_orden`) REFERENCES `orden` (`id`);

--
-- Constraints for table `orden`
--
ALTER TABLE `orden`
  ADD CONSTRAINT `orden_ibfk_1` FOREIGN KEY (`id_comida`) REFERENCES `comida` (`id`);

--
-- Constraints for table `restaurante`
--
ALTER TABLE `restaurante`
  ADD CONSTRAINT `restaurante_ibfk_1` FOREIGN KEY (`id_sucursal`) REFERENCES `sucursal` (`id`),
  ADD CONSTRAINT `restaurante_ibfk_2` FOREIGN KEY (`id_cliente`) REFERENCES `cliente` (`id`),
  ADD CONSTRAINT `restaurante_ibfk_3` FOREIGN KEY (`id_comida`) REFERENCES `comida` (`id`);

--
-- Constraints for table `telefonos_clientes`
--
ALTER TABLE `telefonos_clientes`
  ADD CONSTRAINT `telefonos_clientes_ibfk_1` FOREIGN KEY (`id_cliente`) REFERENCES `cliente` (`id`);

--
-- Constraints for table `telefonos_sucursal`
--
ALTER TABLE `telefonos_sucursal`
  ADD CONSTRAINT `telefonos_sucursal_ibfk_1` FOREIGN KEY (`id_sucursal`) REFERENCES `sucursal` (`id`);
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
