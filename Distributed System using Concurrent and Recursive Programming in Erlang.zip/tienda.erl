% Actividad Integradora 6.2 Programación Distribuida en Erlang
% Valeria López Barcelata A00833578
% Roberto Ríos Olaiz A00833125
% ----------------------------------------------------------
-module(tienda).
-export([abre_tienda/0, registra_producto/2, elimina_producto/1, modifica_producto/2, cierra_tienda/0, lista_socios/0, productos_vendidos/0]).

% Instrucciones:
% 1. Abrir símbolo del sistema o terminal
% 2. Navegar a la ruta donde se encuentran los archivos tienda.erl y socio.erl
% 3. Escribir el siguiente comando para crear el nodo "nodo_tienda":
%    werl -sname nodo_tienda -setcookie mycookie
% 4. Compilar el módulo "tienda" en el emulador de Erlang:
%    c(tienda).
% 5. Inicializar el proceso tienda con el comando:
%    tienda:abre_tienda().
% 6. Si se desea abrir el nodo socio en el mismo nodo, compilar el módulo socio:
%    c(socio).
% 7. Para abrir el nodo socio desde otro nodo, seguir las instrucciones en socio.erl
% 8. Probar las funcionalidades de la tienda y los casos de prueba
% 9. Al terminar, cerrar el proceso tienda:
%    tienda:cierra_tienda().

% Nota: nodo_tienda y los nodos_socio deben estar ubicados en el mismo host

% Se crea el proceso con nombre tienda que llama a la función tienda_proceso con listas vacías de socios, productos, y registro, y el contador de pedidos en 0.
abre_tienda() ->
  io:format("Abriendo tienda...~n"),
  register(tienda, spawn(fun() -> tienda_proceso([], [], 0, []) end)).

% Función tienda_proceso que mantiene el ciclo de la información de socios, productos, y pedidos
tienda_proceso(Socios, Productos, PedidosCont, Registro) ->
  receive
    % Socios:
    {suscribe_socio, Socio, P} -> % Recibe mensaje suscribe_socio
      case lists:member(Socio, Socios) of
        true -> % El socio ya existe en la lista y regresa el mensaje "socio_suscrito, false" al socio
          P ! {socio_suscrito, false},
          tienda_proceso(Socios, Productos, PedidosCont, Registro);
        false -> % Se registra el nuevo socio y regresa mensaje "socio_suscrito, true" al socio
          P ! {socio_suscrito, true},
          io:format("Solicitud recibida: suscribiendo socio ~p~n", [Socio]), % Despliega la solicitud recibida en el nodo_tienda
          tienda_proceso(Socios ++ [Socio], Productos, PedidosCont, Registro) % Agrega el socio a la lista de Socios
      end;

    {elimina_socio, Socio, P} -> % Recibe mensaje elimina_socio
      case lists:member(Socio, Socios) of
        true -> % Elimina el socio de la lista y regresa el mensaje "socio_eliminado, true" al socio
          P ! {socio_eliminado, true},
          io:format("Solicitud recibida: eliminando socio ~p~n", [Socio]), % Despliega la solicitud recibida en el nodo_tienda
          tienda_proceso(lists:delete(Socio, Socios), Productos, PedidosCont, Registro); % Elimina el socio de la lista Socios
        false -> % El socio no existe y regresa el mensaje "socio_eliminado, false" al socio
          P ! {socio_eliminado, false},
          tienda_proceso(Socios, Productos, PedidosCont, Registro)
      end;

    {lista_socios, P} -> % Recibe el mensaje lista_socios
      P ! {lista, Socios}, % Regresa la lista de socios al socio
      tienda_proceso(Socios, Productos, PedidosCont, Registro);

    % Pedidos
    {crea_pedido, Socio, ListaDeProductos, P} -> % Recibe mensaje crea_pedido
      CreaPedido = fun({Producto, Cantidad}, {Pedido, Errores}) -> % Función CreaPedido que recibe los elementos {Producto, Cantidad} y acumula las listas Pedido y Errores
        case {lists:keyfind(Producto, 1, Productos), (Cantidad > 0)} of % Si el producto está en la lista de Productos y si la cantidad solicitada es mayor a 0
          {{Producto, Proceso}, true} -> % Encuentra el proceso del producto solicitado, y la cantidad a solicitar es mayor a 0
            io:format("Solicitud recibida: solicitando ~p de producto ~p...~n",[Cantidad, Producto]),
            Proceso ! {modificar, -Cantidad, self()}, % Llama al proceso, restando la cantidad solicitada
            receive
              {cantidad_vendida, CantidadVendida} -> % Recibe mensaje del proceso con la cantidad vendida del producto
                NuevoErrores =
                  if (CantidadVendida < Cantidad) -> % Si la cantidad de productos vendidos fue menor que la cantidad solicitada
                    Errores ++ ["Cantidad en existencia de " ++ atom_to_list(Producto) ++ " insuficiente"]; % Regresar mensaje al socio que la cantidad en existencia fue insuficiente
                  true -> Errores % La cantidad de productos vendidos fue igual que la cantidad solicitada
                  end,
                case lists:keyfind(Producto, 1, Pedido) of % Si el producto ya está en la lista Pedido
                  {Producto, TotalVendidos} -> % El producto ya fue solicitado dentro del mismo pedido
                    io:format("Producto ~p ya existe en el pedido, actualizando cantidad...~n", [Producto]),
                    {lists:keyreplace(Producto, 1, Pedido, {Producto, TotalVendidos + CantidadVendida}), NuevoErrores}; % Actualizar cantidad de productos vendidos en el pedido
                  false -> % Es la primera vez que el producto aparece en el pedido
                    io:format("Agregando producto ~p al pedido...~n", [Producto]),
                    {Pedido ++ [{Producto, CantidadVendida}], NuevoErrores} % Agregar cantidad de productos vendidos al pedido
                end
            end;
          {false, _} -> % No encuentra el producto solicitado
            {Pedido ++ [{Producto, 0}], Errores ++ ["El producto " ++ atom_to_list(Producto) ++ " no existe"]}; % Agrega el producto y cantidad 0, y regresa el error producto inexistente al socio
          {_, false} -> % La cantidad a solicitar es menor o igual a 0
            {Pedido ++ [{Producto, 0}], Errores ++ ["Cantidad solicitada de " ++ atom_to_list(Producto) ++ " inválida"]} % Agrega el producto y cantidad 0, y regresa el error cantidad inválida al socio
        end
      end,
      
      AgregaRegistro = fun({Producto, Cantidad}, R) -> % Función AgregaRegistro que recibe los elementos {Producto, Cantidad} y la lista Registro "R"
        case {lists:keyfind(Producto, 1, R), (Cantidad > 0)} of % Si el producto está en el registro y si la cantidad a surtir es mayor a 0
          {{Producto, TotalVendidos}, true} -> % El producto ya existe en el registro y se vendieron más de 0 productos
            io:format("Producto ~p ya existe en el registro, actualizando cantidad a ~p...~n", [Producto, TotalVendidos + Cantidad]),
            lists:keyreplace(Producto, 1, R, {Producto, TotalVendidos + Cantidad}); % Actualiza las cantidades vendidas del producto
          {false, true} -> % El producto no existe en el registro y se vendieron más de 0 productos
            io:format("Agregando ~p de producto ~p al registro...~n", [Cantidad, Producto]),
            R ++ [{Producto, Cantidad}]; % Agrega el producto nuevo y su cantidad al registro
          {_, false} -> % La cantidad a surtir fue 0 (el producto es inexistente o su cantidad inválida)
            R % No realiza cambios al registro
        end
      end,

      case lists:member(Socio, Socios) of % Si el socio está en la lista de Socios
        true -> % Encuentra el socio en la lista de socios
          io:format("Solicitud recibida: creando pedido para socio ~p...~n", [Socio]),
          {Pedido, Errores} = lists:foldl(CreaPedido, {[], []}, ListaDeProductos), % Crea las listas Pedido y Errores en base a la lista de productos solicitados por el socio
          NuevoRegistro = lists:foldl(AgregaRegistro, Registro, Pedido), % Actualiza el registro con el nuevo pedido
          P ! {pedido_creado, Pedido, Errores, PedidosCont + 1}, % Regresa mensaje "pedido_creado, Pedido, Errores, Num" al socio
          tienda_proceso(Socios, Productos, PedidosCont + 1, NuevoRegistro); % Suma +1 al contador de pedidos
        false -> % No encuentra el socio en la lista de socios
          P ! {pedido_creado, false}, % Regresa mensaje "pedido_creado, false" al socio
          tienda_proceso(Socios, Productos, PedidosCont, Registro)
      end;

    {productos_vendidos, P} -> % Recibe mensaje productos_vendidos
      P ! {lista, Registro, PedidosCont}, % Despliega la lista del Registro en el nodo_tienda
      tienda_proceso(Socios, Productos, PedidosCont, Registro);

    % Productos
    {registra_producto, Producto, Cantidad, P} -> % Recibe mensaje registra_producto
      case lists:keyfind(Producto, 1, Productos) of % Si el producto está en la lista Productos
        {Producto, _} -> % El producto ya existe
          P ! existente, % La tienda despliega el error: producto existente
          tienda_proceso(Socios, Productos, PedidosCont, Registro);
        false -> % El producto no existe
          P ! registrando, % La tienda despliega el mensaje: registrando
          Proceso = spawn(fun() -> producto_proceso(Producto, Cantidad) end), % Crea un nuevo proceso para el producto
          Proceso ! {registrado}, % Envía mensaje al proceso del Producto para confirmar su registro
          tienda_proceso(Socios, Productos ++ [{Producto, Proceso}], PedidosCont, Registro) % Agrega {Producto, Proceso} a la lista Productos
      end;
    
    {elimina_producto, Producto, P} -> % Recibe mensaje elimina_producto
      case lists:keyfind(Producto, 1, Productos) of % Si el producto está en la lista Productos
        false -> % El producto no existe
          P ! inexistente, % La tienda despliega el error: producto inexistente
          tienda_proceso(Socios, Productos, PedidosCont, Registro);
        {Producto, Proceso} -> % El producto ya existe
          P ! eliminando, % La tienda despliega el mensaje: eliminando
          Proceso ! eliminar, % Envía mensaje "eliminar" al proceso del Producto
          tienda_proceso(Socios, lists:delete({Producto, Proceso}, Productos), PedidosCont, Registro) % Elimina el registro del producto de la lista Productos
      end;

    {modifica_producto, Producto, Cantidad, P} -> % Recibe mensaje modifica_producto
      case lists:keyfind(Producto, 1, Productos) of % Si el producto está en la lista Productos
        false -> % El producto no existe
          P ! inexistente; % La tienda despliega el error: producto inexistente
        {Producto, Proceso} -> % El producto ya existe
          P ! modificando, % La tienda despliega el mensaje: modificando
          Proceso ! {modificar, Cantidad, self()}, % Envía mensaje "modificar" al proceso del Producto con la cantidad a modificar
          receive
            {cantidad_vendida, _} -> ok % Recibe mensaje con la cantidad vendida: para la tienda no es necesario conocer la cantidad vendida
          end
      end,
      tienda_proceso(Socios, Productos, PedidosCont, Registro);

    {lista_productos, P} -> % Recibe mensaje lista_productos
      NombreProducto = % Función NombreProducto que recibe los elementos {Producto, _}
        fun({Producto, _}) -> Producto end, % Regresa solamente el nombre del Producto
      P ! {lista, lists:map(NombreProducto, Productos)}, % Envía lista de nombres de productos activos al socio
      tienda_proceso(Socios, Productos, PedidosCont, Registro);

    cierra_tienda -> % Recibe mensaje cierra_tienda
      EliminaProcesos = % Función EliminaProcesos que recibe los elementos {_, Proceso}
        fun({_, Proceso}) -> Proceso ! eliminar end, % Envía mensaje "eliminar" a cada Proceso
      lists:foreach(EliminaProcesos, Productos), % Aplica a todos los elementos de la lista Productos
      ok % Termina ciclo de tienda_proceso
  end.

% Función producto_proceso que mantiene el ciclo activo del manejo de la cantidad del producto
producto_proceso(Producto, Cantidad) ->
  receive
    registrado -> % Recibe mensaje registrado
      io:format("Producto ~p registrado!~n", [Producto]),
      producto_proceso(Producto, Cantidad);
    eliminar -> % Recibe mensaje eliminar
      io:format("Producto ~p eliminado!~n", [Producto]),
      ok; % Termina ciclo de producto_proceso
    {modificar, Valor, P} -> % Recibe mensaje modificar
      case (Valor > 0) of % Si valor a agregar es positivo o negativo
        true -> % Números positivos: solamente la tienda puede agregar productos
          CantidadRestada = 0,
          NuevaCantidad = Cantidad + Valor,
          io:format("Producto ~p modificado!~n", [Producto]),
          io:format("Cantidad Agregada: ~p~n", [Valor]),
          io:format("Nueva Cantidad: ~p~n", [NuevaCantidad]);
        false -> % Números negativos: La tienda puede restar productos y los socios pueden solicitar productos en sus pedidos
          if (Cantidad + Valor < 0) -> % El valor es un número negativo mayor que la cantidad existente
            CantidadRestada = Cantidad, % Solo se resta la cantidad de existencias
            NuevaCantidad = 0, % La nueva cantidad se reinicia en 0
            io:format("Cantidad en existencia insuficiente~n");
          true -> % El valor es un número negativo menor que la cantidad existente
            CantidadRestada = -Valor, % Se resta la cantidad del valor solicitado
            NuevaCantidad = Cantidad + Valor % La nueva cantidad es la resta
          end,
          io:format("Producto ~p modificado!~n", [Producto]),
          io:format("Cantidad Restada: ~p~n", [CantidadRestada]),
          io:format("Nueva Cantidad: ~p~n", [NuevaCantidad])
      end,
      timer:sleep(1), % Termina de imprimir todos los mensajes en nodo_tienda
      P ! {cantidad_vendida, CantidadRestada}, % Envía mensaje a la función CreaPedido con las unidades vendidas del producto
      producto_proceso(Producto, NuevaCantidad)
  end.

%Si la cantidad de producto que se registra es mayor a 0, se llama a la tienda con el mensaje registra_producto, y se le proporciona el producto y cantidad que se desea registrar.
registra_producto(Producto, Cantidad) ->
  if (Cantidad >= 0) ->
    llama_tienda({registra_producto, Producto, Cantidad, self()});
  true -> 
    io:format("La cantidad inicial debe ser un número entero mayor o igual a 0~n")
  end.
%Funcion elimina producto. Envia mensaje a proceso Tienda con producto a eliminar.
elimina_producto(Producto) ->
  llama_tienda({elimina_producto, Producto, self()}).
%Funcion modifica producto. Envia mensaje a proceso Tienda con producto a modificar y nueva cantidad.
modifica_producto(Producto, Cantidad) ->
  llama_tienda({modifica_producto, Producto, Cantidad, self()}).
%Funcion lista_socios. Envía mensaje a Tienda para que regrese una lista con los socios registrados.
lista_socios() ->
  llama_tienda({lista_socios, self()}).
%Funcion productos vendidos. Envía mensaje a Tienda para que regrese la lista de registro.
productos_vendidos() ->
  llama_tienda({productos_vendidos, self()}).

%mensajes que recibe dependiendo de casos externos de llamadas de socios a tienda
llama_tienda(Mensaje) ->
  tienda ! Mensaje,
  receive
    {lista, Socios} ->
      io:format("Lista de Socios: ~p~n", [Socios]);
    {lista, Registro, Pedidos} ->
      io:format("Lista de Productos Vendidos: ~p~n", [Registro]),
      io:format("Cantidad de Pedidos: ~p~n", [Pedidos]);
    registrando ->
      io:format("Registrando producto...~n");
    eliminando ->
      io:format("Eliminando producto...~n");
    modificando ->
      io:format("Modificando producto...~n");
    inexistente ->
      io:format("El producto no existe~n");
    existente ->
      io:format("El producto ya existe~n")
  end.

cierra_tienda() ->
  io:format("Cerrando tienda...~n"),
  tienda ! cierra_tienda,
  unregister(tienda).