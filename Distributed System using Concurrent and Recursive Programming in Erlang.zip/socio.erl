% Actividad Integradora 6.2 Programación Distribuida en Erlang
% Valeria López Barcelata A00833578
% Roberto Ríos Olaiz A00833125
% ----------------------------------------------------------
-module(socio).
-export([suscribir_socio/1, elimina_socio/1, crea_pedido/2, lista_existencias/0]).

% Instrucciones:
% 1. Abrir símbolo del sistema o terminal
% 2. Navegar a la ruta donde se encuentran los archivos tienda.erl y socio.erl
% 3. Escribir el siguiente comando para crear el nodo "nodo_socio":
%    werl -sname nodo_socio -setcookie mycookie
% 4. Compilar el módulo "socio" en el emulador de Erlang:
%    c(socio).
% 5. Asegurar que el siguiente comando ya haya sido ejecutado en el nodo_tienda:
%    tienda:abre_tienda().
% 6. Probar las funcionalidades del socio y los casos de prueba

% Nota: nodo_tienda y los nodos_socio deben estar ubicados en el mismo host

% Función suscribe socio. Envía mensaje a Tienda con socio a suscribir
suscribir_socio(Socio) ->
  llama_tienda({suscribe_socio, Socio, self()}).

% Función elimina socio. Envía mensaje a Tienda con socio a eliminar
elimina_socio(Socio) ->
  llama_tienda({elimina_socio, Socio, self()}).

% Función crea pedido. Envía mensaje a Tienda con lista de tuplas {Producto, Cantidad}
crea_pedido(Socio, ListaDeProductos) ->
  llama_tienda({crea_pedido, Socio, ListaDeProductos, self()}).

% Despliega productos activos, envia mensaje a Tienda.
lista_existencias() ->
  llama_tienda({lista_productos, self()}).

conecta_nodo() ->
  {ok, Hostname} = inet:gethostname(), % Obtiene el nombre del host donde se encuentran los nodos
  case whereis(tienda) of
    undefined -> % El socio está conectado desde otro nodo
      {tienda, list_to_atom("nodo_tienda@" ++ Hostname)}; % Envía mensaje al proceso tienda en nodo_tienda
    _ -> % El socio está conectado en el mismo nodo
      io:format("tienda~n"),
      tienda % Envía mensaje al proceso tienda
  end.

llama_tienda(Mensaje) ->
  conecta_nodo() ! Mensaje,
  receive
    {socio_suscrito, true} ->
      io:format("Mensaje recibido: suscripción realizada~n");
    {socio_suscrito, false} ->
      io:format("Mensaje recibido: socio ya existe~n");
    {socio_eliminado, true} ->
      io:format("Mensaje recibido: socio eliminado~n");
    {socio_eliminado, false} ->
      io:format("Mensaje recibido: socio no existe~n");
    {pedido_creado, false} ->
      io:format("Mensaje recibido: imposible realizar pedido, socio no válido~n");
    {pedido_creado, Pedido, Errores, Num} ->
      io:format("Errores encontrados: ~p~n", [Errores]),
      io:format("Número de pedido: ~p~n", [Num]),
      io:format("Pedido creado: ~p~n", [Pedido]);
    {lista, Productos} ->
      io:format("Mensaje recibido, lista de productos: ~p~n", [Productos])
  end.